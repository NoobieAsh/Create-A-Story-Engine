import { useState } from "react";
import { LocationCard, type Location } from "@/components/LocationCard";
import { SearchBar } from "@/components/SearchBar";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, MapPin, BookOpen } from "lucide-react";

// todo: remove mock functionality
const mockLocations: Location[] = [
  { id: "1", name: "The Lighthouse", description: "Ancient beacon on the cliff's edge", occurrences: 15, stories: ["The Lighthouse Keeper", "Morning Reflections"] },
  { id: "2", name: "Crystal Garden", description: "Where dreams take root and bloom", occurrences: 12, stories: ["The Garden of Dreams", "Whispers at Twilight"] },
  { id: "3", name: "The Floating City", description: "Suspended between clouds and sea", occurrences: 8, stories: ["Flying Over Cities"] },
  { id: "4", name: "Ancient Library", description: "Endless halls of forgotten knowledge", occurrences: 6, stories: ["A Letter Never Sent"] },
  { id: "5", name: "Twilight Shore", description: "Where day and night meet", occurrences: 5, stories: ["Whispers at Twilight"] },
  { id: "6", name: "The Wanderer's Inn", description: "Rest stop for lost souls", occurrences: 4, stories: ["The Lighthouse Keeper"] },
];

export default function Locations() {
  const [search, setSearch] = useState("");
  const [locations] = useState(mockLocations);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newLocationName, setNewLocationName] = useState("");
  const [newLocationDesc, setNewLocationDesc] = useState("");

  const filteredLocations = locations.filter(
    (loc) =>
      loc.name.toLowerCase().includes(search.toLowerCase()) ||
      loc.description?.toLowerCase().includes(search.toLowerCase())
  );

  const handleLocationClick = (location: Location) => {
    setSelectedLocation(location);
    setIsDialogOpen(true);
  };

  const handleAddLocation = () => {
    if (newLocationName.trim()) {
      console.log("Adding location:", { name: newLocationName, description: newLocationDesc });
      setNewLocationName("");
      setNewLocationDesc("");
      setIsAddDialogOpen(false);
    }
  };

  const totalOccurrences = locations.reduce((sum, l) => sum + l.occurrences, 0);

  return (
    <div className="h-full overflow-auto" data-testid="page-locations">
      <header className="flex items-center justify-between gap-4 p-4 md:p-6 border-b flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold">Locations</h1>
          <p className="text-sm text-muted-foreground">
            {locations.length} places in your creative world
          </p>
        </div>
        <div className="flex items-center gap-4 flex-wrap">
          <SearchBar
            value={search}
            onChange={setSearch}
            placeholder="Search locations..."
          />
          <Button onClick={() => setIsAddDialogOpen(true)} data-testid="button-add-location">
            <Plus className="h-4 w-4 mr-2" />
            Add Location
          </Button>
        </div>
      </header>

      <main className="p-4 md:p-6 space-y-6">
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="p-2 rounded-md bg-chart-3/10">
                <MapPin className="h-5 w-5 text-chart-3" />
              </div>
              <div>
                <p className="text-2xl font-bold">{locations.length}</p>
                <p className="text-sm text-muted-foreground">Total Locations</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="p-2 rounded-md bg-chart-4/10">
                <BookOpen className="h-5 w-5 text-chart-4" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalOccurrences}</p>
                <p className="text-sm text-muted-foreground">Total Mentions</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {filteredLocations.length > 0 ? (
          <div className="grid gap-3 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {filteredLocations.map((location) => (
              <LocationCard
                key={location.id}
                location={location}
                onClick={() => handleLocationClick(location)}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-48 text-center">
            <p className="text-muted-foreground mb-2">No locations found</p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add your first location
            </Button>
          </div>
        )}
      </main>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedLocation?.name}</DialogTitle>
          </DialogHeader>
          {selectedLocation && (
            <div className="space-y-4">
              {selectedLocation.description && (
                <div>
                  <Label className="text-sm text-muted-foreground">Description</Label>
                  <p className="font-medium">{selectedLocation.description}</p>
                </div>
              )}
              <div>
                <Label className="text-sm text-muted-foreground">Appearances</Label>
                <p className="font-mono">{selectedLocation.occurrences} mentions</p>
              </div>
              <div>
                <Label className="text-sm text-muted-foreground">Stories</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {selectedLocation.stories.map((story) => (
                    <Badge key={story} variant="secondary">
                      {story}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Location</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={newLocationName}
                onChange={(e) => setNewLocationName(e.target.value)}
                placeholder="Location name"
                data-testid="input-location-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description (optional)</Label>
              <Textarea
                id="description"
                value={newLocationDesc}
                onChange={(e) => setNewLocationDesc(e.target.value)}
                placeholder="Describe this place..."
                data-testid="input-location-description"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddLocation} disabled={!newLocationName.trim()} data-testid="button-save-location">
              Add Location
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
