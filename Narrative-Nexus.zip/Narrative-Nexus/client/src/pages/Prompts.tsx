import { useState } from "react";
import { PromptCard, type Prompt } from "@/components/PromptCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Sparkles, Settings2 } from "lucide-react";

// todo: remove mock functionality
const mockPrompts: Prompt[] = [
  {
    id: "1",
    text: "Write about a character who discovers that their recurring dream is actually a memory from someone else's life.",
    genre: "mystery",
    complexity: "moderate",
    themes: ["identity", "memory", "connection"],
  },
  {
    id: "2",
    text: "Describe a world where emotions manifest as physical weather patterns.",
    genre: "fantasy",
    complexity: "complex",
    themes: ["emotions", "nature", "symbolism"],
  },
  {
    id: "3",
    text: "A letter written to someone who will never read it.",
    genre: "literary",
    complexity: "simple",
    themes: ["loss", "regret", "hope"],
  },
];

// todo: remove mock functionality
const mockSavedPrompts: Prompt[] = [
  {
    id: "4",
    text: "The last lighthouse keeper prepares for a visitor who arrives only once every hundred years.",
    genre: "fantasy",
    complexity: "moderate",
    themes: ["solitude", "time", "duty"],
  },
];

const genreOptions = ["fantasy", "mystery", "literary", "sci-fi", "horror", "romance"];

export default function Prompts() {
  const [prompts, setPrompts] = useState(mockPrompts);
  const [savedPrompts, setSavedPrompts] = useState(mockSavedPrompts);
  const [complexity, setComplexity] = useState([50]);
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [useMyThemes, setUseMyThemes] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);

  const toggleSaved = (promptId: string) => {
    const prompt = [...prompts, ...savedPrompts].find((p) => p.id === promptId);
    if (!prompt) return;

    if (savedPrompts.find((p) => p.id === promptId)) {
      setSavedPrompts(savedPrompts.filter((p) => p.id !== promptId));
    } else {
      setSavedPrompts([...savedPrompts, prompt]);
    }
  };

  const toggleGenre = (genre: string) => {
    if (selectedGenres.includes(genre)) {
      setSelectedGenres(selectedGenres.filter((g) => g !== genre));
    } else {
      setSelectedGenres([...selectedGenres, genre]);
    }
  };

  const generateNewPrompts = () => {
    setIsGenerating(true);
    // todo: remove mock functionality - simulate API call
    setTimeout(() => {
      setPrompts([
        {
          id: Date.now().toString(),
          text: "A musician discovers their instrument can only play songs from moments in their past they've forgotten.",
          genre: selectedGenres[0] || "literary",
          complexity: complexity[0] < 33 ? "simple" : complexity[0] < 66 ? "moderate" : "complex",
          themes: ["memory", "art", "discovery"],
        },
        {
          id: (Date.now() + 1).toString(),
          text: "Write about the conversation between two strangers stuck in an elevator who realize they've met before in a dream.",
          genre: selectedGenres[1] || "mystery",
          complexity: complexity[0] < 33 ? "simple" : complexity[0] < 66 ? "moderate" : "complex",
          themes: ["fate", "connection", "dreams"],
        },
        {
          id: (Date.now() + 2).toString(),
          text: "A garden where plants grow based on the gardener's emotional state.",
          genre: selectedGenres[2] || "fantasy",
          complexity: complexity[0] < 33 ? "simple" : complexity[0] < 66 ? "moderate" : "complex",
          themes: ["nature", "emotions", "growth"],
        },
      ]);
      setIsGenerating(false);
    }, 1000);
  };

  const handleUsePrompt = (prompt: Prompt) => {
    console.log("Starting entry with prompt:", prompt.text);
  };

  return (
    <div className="h-full overflow-auto" data-testid="page-prompts">
      <header className="p-4 md:p-6 border-b">
        <h1 className="text-2xl font-semibold">Writing Prompts</h1>
        <p className="text-sm text-muted-foreground">
          AI-generated inspiration based on your writing style
        </p>
      </header>

      <main className="p-4 md:p-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
          <div className="space-y-6">
            <Tabs defaultValue="generated" className="w-full">
              <div className="flex items-center justify-between gap-4 mb-4 flex-wrap">
                <TabsList>
                  <TabsTrigger value="generated" data-testid="tab-generated-prompts">
                    <Sparkles className="h-4 w-4 mr-1" />
                    Generated
                  </TabsTrigger>
                  <TabsTrigger value="saved" data-testid="tab-saved-prompts">
                    Saved ({savedPrompts.length})
                  </TabsTrigger>
                </TabsList>
                <Button
                  onClick={generateNewPrompts}
                  disabled={isGenerating}
                  data-testid="button-generate-prompts"
                >
                  <RefreshCw className={`h-4 w-4 mr-2 ${isGenerating ? "animate-spin" : ""}`} />
                  {isGenerating ? "Generating..." : "Generate New"}
                </Button>
              </div>

              <TabsContent value="generated" className="mt-0">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                  {prompts.map((prompt) => (
                    <PromptCard
                      key={prompt.id}
                      prompt={prompt}
                      isSaved={savedPrompts.some((p) => p.id === prompt.id)}
                      onRefresh={generateNewPrompts}
                      onSave={() => toggleSaved(prompt.id)}
                      onUse={() => handleUsePrompt(prompt)}
                    />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="saved" className="mt-0">
                {savedPrompts.length > 0 ? (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                    {savedPrompts.map((prompt) => (
                      <PromptCard
                        key={prompt.id}
                        prompt={prompt}
                        isSaved={true}
                        onSave={() => toggleSaved(prompt.id)}
                        onUse={() => handleUsePrompt(prompt)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-48 text-center">
                    <p className="text-muted-foreground mb-2">No saved prompts yet</p>
                    <p className="text-sm text-muted-foreground">
                      Save prompts you like to use them later
                    </p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Settings2 className="h-4 w-4" />
                  Prompt Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Complexity</Label>
                  <Slider
                    value={complexity}
                    onValueChange={setComplexity}
                    max={100}
                    step={1}
                    className="w-full"
                    data-testid="slider-complexity"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Simple</span>
                    <span>Moderate</span>
                    <span>Complex</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Genres</Label>
                  <div className="flex flex-wrap gap-2">
                    {genreOptions.map((genre) => (
                      <Badge
                        key={genre}
                        variant={selectedGenres.includes(genre) ? "default" : "outline"}
                        className="cursor-pointer capitalize"
                        onClick={() => toggleGenre(genre)}
                        data-testid={`genre-${genre}`}
                      >
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-sm font-medium">Use My Themes</Label>
                    <p className="text-xs text-muted-foreground">
                      Generate based on your motifs
                    </p>
                  </div>
                  <Switch
                    checked={useMyThemes}
                    onCheckedChange={setUseMyThemes}
                    data-testid="switch-use-themes"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
