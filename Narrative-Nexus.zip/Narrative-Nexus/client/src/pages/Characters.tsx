import { useState } from "react";
import { CharacterCard, type Character } from "@/components/CharacterCard";
import { SearchBar } from "@/components/SearchBar";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, BookOpen, Users } from "lucide-react";

// todo: remove mock functionality
const mockCharacters: Character[] = [
  { id: "1", name: "Elena Vance", role: "Protagonist", occurrences: 24, stories: ["The Lighthouse Keeper", "Morning Reflections"] },
  { id: "2", name: "Marcus Webb", role: "Guide", occurrences: 18, stories: ["The Lighthouse Keeper", "Flying Over Cities"] },
  { id: "3", name: "Lily Chen", role: "Companion", occurrences: 12, stories: ["The Garden of Dreams", "Whispers at Twilight"] },
  { id: "4", name: "The Old Sage", role: "Mentor", occurrences: 8, stories: ["A Letter Never Sent"] },
  { id: "5", name: "River", role: "Spirit", occurrences: 6, stories: ["The Garden of Dreams"] },
  { id: "6", name: "Captain Shaw", role: "Antagonist", occurrences: 5, stories: ["The Lighthouse Keeper"] },
];

export default function Characters() {
  const [search, setSearch] = useState("");
  const [characters] = useState(mockCharacters);
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newCharacterName, setNewCharacterName] = useState("");
  const [newCharacterRole, setNewCharacterRole] = useState("");

  const filteredCharacters = characters.filter(
    (char) =>
      char.name.toLowerCase().includes(search.toLowerCase()) ||
      char.role?.toLowerCase().includes(search.toLowerCase())
  );

  const handleCharacterClick = (character: Character) => {
    setSelectedCharacter(character);
    setIsDialogOpen(true);
  };

  const handleAddCharacter = () => {
    if (newCharacterName.trim()) {
      console.log("Adding character:", { name: newCharacterName, role: newCharacterRole });
      setNewCharacterName("");
      setNewCharacterRole("");
      setIsAddDialogOpen(false);
    }
  };

  const totalOccurrences = characters.reduce((sum, c) => sum + c.occurrences, 0);

  return (
    <div className="h-full overflow-auto" data-testid="page-characters">
      <header className="flex items-center justify-between gap-4 p-4 md:p-6 border-b flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold">Characters</h1>
          <p className="text-sm text-muted-foreground">
            {characters.length} characters across your writing
          </p>
        </div>
        <div className="flex items-center gap-4 flex-wrap">
          <SearchBar
            value={search}
            onChange={setSearch}
            placeholder="Search characters..."
          />
          <Button onClick={() => setIsAddDialogOpen(true)} data-testid="button-add-character">
            <Plus className="h-4 w-4 mr-2" />
            Add Character
          </Button>
        </div>
      </header>

      <main className="p-4 md:p-6 space-y-6">
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="p-2 rounded-md bg-chart-1/10">
                <Users className="h-5 w-5 text-chart-1" />
              </div>
              <div>
                <p className="text-2xl font-bold">{characters.length}</p>
                <p className="text-sm text-muted-foreground">Total Characters</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="p-2 rounded-md bg-chart-2/10">
                <BookOpen className="h-5 w-5 text-chart-2" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalOccurrences}</p>
                <p className="text-sm text-muted-foreground">Total Mentions</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {filteredCharacters.length > 0 ? (
          <div className="grid gap-3 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {filteredCharacters.map((character) => (
              <CharacterCard
                key={character.id}
                character={character}
                onClick={() => handleCharacterClick(character)}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-48 text-center">
            <p className="text-muted-foreground mb-2">No characters found</p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add your first character
            </Button>
          </div>
        )}
      </main>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedCharacter?.name}</DialogTitle>
          </DialogHeader>
          {selectedCharacter && (
            <div className="space-y-4">
              {selectedCharacter.role && (
                <div>
                  <Label className="text-sm text-muted-foreground">Role</Label>
                  <p className="font-medium">{selectedCharacter.role}</p>
                </div>
              )}
              <div>
                <Label className="text-sm text-muted-foreground">Appearances</Label>
                <p className="font-mono">{selectedCharacter.occurrences} mentions</p>
              </div>
              <div>
                <Label className="text-sm text-muted-foreground">Stories</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {selectedCharacter.stories.map((story) => (
                    <Badge key={story} variant="secondary">
                      {story}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Character</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={newCharacterName}
                onChange={(e) => setNewCharacterName(e.target.value)}
                placeholder="Character name"
                data-testid="input-character-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Role (optional)</Label>
              <Input
                id="role"
                value={newCharacterRole}
                onChange={(e) => setNewCharacterRole(e.target.value)}
                placeholder="e.g., Protagonist, Mentor"
                data-testid="input-character-role"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddCharacter} disabled={!newCharacterName.trim()} data-testid="button-save-character">
              Add Character
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
