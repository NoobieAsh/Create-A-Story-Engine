import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Save, Download, Trash2 } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const [autoSave, setAutoSave] = useState(true);
  const [autoAnalyze, setAutoAnalyze] = useState(true);
  const [defaultType, setDefaultType] = useState("journal");
  const [exportFormat, setExportFormat] = useState("json");

  const handleSave = () => {
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated.",
    });
  };

  const handleExport = () => {
    toast({
      title: "Export started",
      description: `Preparing your data as ${exportFormat.toUpperCase()}...`,
    });
  };

  return (
    <div className="h-full overflow-auto" data-testid="page-settings">
      <header className="p-4 md:p-6 border-b">
        <h1 className="text-2xl font-semibold">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Customize your Muse experience
        </p>
      </header>

      <main className="p-4 md:p-6 max-w-2xl space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Writing Preferences</CardTitle>
            <CardDescription>Configure how you write and save entries</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-save</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically save entries while writing
                </p>
              </div>
              <Switch
                checked={autoSave}
                onCheckedChange={setAutoSave}
                data-testid="switch-autosave"
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-analyze</Label>
                <p className="text-sm text-muted-foreground">
                  Run analysis automatically after saving
                </p>
              </div>
              <Switch
                checked={autoAnalyze}
                onCheckedChange={setAutoAnalyze}
                data-testid="switch-autoanalyze"
              />
            </div>
            <Separator />
            <div className="space-y-2">
              <Label>Default entry type</Label>
              <Select value={defaultType} onValueChange={setDefaultType}>
                <SelectTrigger className="w-48" data-testid="select-default-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="story">Story</SelectItem>
                  <SelectItem value="journal">Journal</SelectItem>
                  <SelectItem value="dream">Dream</SelectItem>
                  <SelectItem value="poem">Poem</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>AI Analysis</CardTitle>
            <CardDescription>Configure the AI-powered analysis features</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="apiKey">OpenAI API Key</Label>
              <Input
                id="apiKey"
                type="password"
                placeholder="sk-..."
                data-testid="input-api-key"
              />
              <p className="text-xs text-muted-foreground">
                Required for sentiment analysis and prompt generation
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Data Management</CardTitle>
            <CardDescription>Export or manage your creative archive</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label>Export Format</Label>
              <div className="flex gap-2 flex-wrap">
                <Select value={exportFormat} onValueChange={setExportFormat}>
                  <SelectTrigger className="w-32" data-testid="select-export-format">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="json">JSON</SelectItem>
                    <SelectItem value="markdown">Markdown</SelectItem>
                    <SelectItem value="pdf">PDF</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" onClick={handleExport} data-testid="button-export">
                  <Download className="h-4 w-4 mr-2" />
                  Export All
                </Button>
              </div>
            </div>
            <Separator />
            <div className="space-y-2">
              <Label className="text-destructive">Danger Zone</Label>
              <p className="text-sm text-muted-foreground">
                These actions are irreversible
              </p>
              <Button variant="destructive" size="sm" data-testid="button-delete-all">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete All Data
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button onClick={handleSave} data-testid="button-save-settings">
            <Save className="h-4 w-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </main>
    </div>
  );
}
