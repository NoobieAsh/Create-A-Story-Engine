import { useState } from "react";
import { EntryCard, type Entry, type EntryType } from "@/components/EntryCard";
import { SearchBar } from "@/components/SearchBar";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { EntryEditor } from "@/components/EntryEditor";
import { AnalysisPanel } from "@/components/AnalysisPanel";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import type { Sentiment } from "@/components/SentimentDisplay";
import type { Motif } from "@/components/MotifTag";
import type { Character } from "@/components/CharacterCard";
import type { Location } from "@/components/LocationCard";

// todo: remove mock functionality
const mockEntries: Entry[] = [
  {
    id: "1",
    title: "The Garden of Forgotten Dreams",
    content: "I walked through a garden where flowers bloomed in impossible colors. Each petal held a memory I thought I had lost forever. The path wound deeper, and with each step, the air grew thick with nostalgia and the scent of rain on summer earth.",
    type: "dream",
    date: "Dec 4, 2024",
    wordCount: 342,
    mood: "Nostalgic",
    moodScore: 72,
  },
  {
    id: "2",
    title: "Morning Reflections",
    content: "The coffee grows cold as I write. Today marks three years since I started this practice. The words come easier now, flowing like water from a spring that I never knew existed within me.",
    type: "journal",
    date: "Dec 3, 2024",
    wordCount: 156,
    mood: "Peaceful",
    moodScore: 85,
  },
  {
    id: "3",
    title: "Whispers at Twilight",
    content: "Between the dying light and stars, a moment hangs suspended. The trees lean close to share their secrets with the wind, and I, a humble witness, catch only fragments of their ancient song.",
    type: "poem",
    date: "Dec 2, 2024",
    wordCount: 89,
    mood: "Contemplative",
    moodScore: 68,
  },
  {
    id: "4",
    title: "The Lighthouse Keeper",
    content: "Marcus had kept the lighthouse running for forty years. Each night, he would climb the spiral stairs, his joints protesting with every step. But tonight was different. Tonight, someone was waiting in the lamp room.",
    type: "story",
    date: "Dec 1, 2024",
    wordCount: 2847,
    mood: "Suspenseful",
    moodScore: 76,
  },
  {
    id: "5",
    title: "Flying Over Cities",
    content: "I soared above a city that was both familiar and strange. Buildings twisted into impossible shapes, and the streets below pulsed with golden light. I knew I had to find something, but I could not remember what.",
    type: "dream",
    date: "Nov 30, 2024",
    wordCount: 278,
    mood: "Anxious",
    moodScore: 58,
  },
  {
    id: "6",
    title: "A Letter Never Sent",
    content: "There are words I carry that will never reach you. They sit in my chest like stones, smooth from years of turning them over. Perhaps one day I will set them free, but not today. Today, I will let them rest.",
    type: "poem",
    date: "Nov 29, 2024",
    wordCount: 124,
    mood: "Melancholy",
    moodScore: 45,
  },
];

// todo: remove mock functionality
const mockAnalysis = {
  sentiment: { label: "Wonder", score: 78, intensity: "high" as const },
  motifs: [
    { id: "1", name: "Water", count: 12, category: "symbol" as const },
    { id: "2", name: "Journey", count: 8, category: "theme" as const },
    { id: "3", name: "Light", count: 6, category: "imagery" as const },
    { id: "4", name: "The Sage", count: 4, category: "archetype" as const },
  ] as Motif[],
  characters: [
    { id: "1", name: "Marcus Webb", role: "Keeper", occurrences: 8, stories: [] },
    { id: "2", name: "Elena", role: "Traveler", occurrences: 5, stories: [] },
  ] as Character[],
  locations: [
    { id: "1", name: "The Lighthouse", occurrences: 6, stories: [] },
    { id: "2", name: "Crystal Garden", occurrences: 4, stories: [] },
  ] as Location[],
};

export default function Archive() {
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<EntryType[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<Entry | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<typeof mockAnalysis | null>(null);

  const filteredEntries = mockEntries.filter((entry) => {
    const matchesSearch =
      entry.title.toLowerCase().includes(search.toLowerCase()) ||
      entry.content.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filters.length === 0 || filters.includes(entry.type);
    return matchesSearch && matchesFilter;
  });

  const handleEntryClick = (entry: Entry) => {
    setSelectedEntry(entry);
    setIsEditorOpen(true);
    setAnalysis(mockAnalysis);
  };

  const handleNewEntry = () => {
    setSelectedEntry(null);
    setIsEditorOpen(true);
    setAnalysis(null);
  };

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    // todo: remove mock functionality - simulate API call
    setTimeout(() => {
      setAnalysis(mockAnalysis);
      setIsAnalyzing(false);
    }, 1500);
  };

  const handleSave = (data: { title: string; content: string; type: EntryType }) => {
    console.log("Saving entry:", data);
    setIsEditorOpen(false);
  };

  return (
    <div className="h-full flex flex-col" data-testid="page-archive">
      <header className="flex items-center justify-between gap-4 p-4 border-b flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold">Literary Archive</h1>
          <p className="text-sm text-muted-foreground">
            {filteredEntries.length} entries
          </p>
        </div>
        <div className="flex items-center gap-4 flex-wrap">
          <SearchBar
            value={search}
            onChange={setSearch}
            filters={filters}
            onFiltersChange={setFilters}
          />
          <Button onClick={handleNewEntry} className="md:hidden" size="icon" data-testid="button-new-entry-mobile">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <main className="flex-1 overflow-auto p-4 md:p-6">
        {filteredEntries.length > 0 ? (
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {filteredEntries.map((entry) => (
              <EntryCard
                key={entry.id}
                entry={entry}
                onClick={() => handleEntryClick(entry)}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <p className="text-muted-foreground mb-4">
              {search || filters.length > 0
                ? "No entries match your search"
                : "No entries yet. Start writing!"}
            </p>
            <Button onClick={handleNewEntry} data-testid="button-create-first">
              <Plus className="h-4 w-4 mr-2" />
              Create your first entry
            </Button>
          </div>
        )}
      </main>

      <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
        <DialogContent className="max-w-5xl h-[85vh] p-0 gap-0">
          <div className="flex h-full">
            <div className="flex-1 min-w-0">
              <EntryEditor
                initialTitle={selectedEntry?.title}
                initialContent={selectedEntry?.content}
                initialType={selectedEntry?.type}
                onSave={handleSave}
                onCancel={() => setIsEditorOpen(false)}
                onAnalyze={handleAnalyze}
                isAnalyzing={isAnalyzing}
              />
            </div>
            <div className="w-80 border-l hidden lg:block">
              <AnalysisPanel
                sentiment={analysis?.sentiment}
                motifs={analysis?.motifs}
                characters={analysis?.characters}
                locations={analysis?.locations}
              />
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
