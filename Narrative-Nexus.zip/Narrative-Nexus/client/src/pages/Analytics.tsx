import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/StatCard";
import { MotifTag, type Motif } from "@/components/MotifTag";
import { FileText, PenLine, Calendar, TrendingUp } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";

// todo: remove mock functionality
const mockStats = {
  totalEntries: 48,
  totalWords: 24562,
  avgWordsPerEntry: 512,
  streakDays: 12,
};

// todo: remove mock functionality
const mockMoodData = [
  { date: "Nov 1", score: 65 },
  { date: "Nov 8", score: 72 },
  { date: "Nov 15", score: 58 },
  { date: "Nov 22", score: 81 },
  { date: "Nov 29", score: 75 },
  { date: "Dec 6", score: 78 },
];

// todo: remove mock functionality
const mockTypeData = [
  { name: "Stories", value: 12, color: "hsl(var(--chart-1))" },
  { name: "Journals", value: 18, color: "hsl(var(--chart-2))" },
  { name: "Dreams", value: 10, color: "hsl(var(--chart-3))" },
  { name: "Poems", value: 8, color: "hsl(var(--chart-4))" },
];

// todo: remove mock functionality
const mockWeeklyData = [
  { day: "Mon", entries: 2 },
  { day: "Tue", entries: 1 },
  { day: "Wed", entries: 3 },
  { day: "Thu", entries: 0 },
  { day: "Fri", entries: 2 },
  { day: "Sat", entries: 4 },
  { day: "Sun", entries: 1 },
];

// todo: remove mock functionality
const mockTopMotifs: Motif[] = [
  { id: "1", name: "Water", count: 24, category: "symbol" },
  { id: "2", name: "Journey", count: 18, category: "theme" },
  { id: "3", name: "Light", count: 15, category: "imagery" },
  { id: "4", name: "The Wanderer", count: 12, category: "archetype" },
  { id: "5", name: "Memory", count: 10, category: "theme" },
  { id: "6", name: "Door", count: 8, category: "symbol" },
  { id: "7", name: "Transformation", count: 7, category: "theme" },
  { id: "8", name: "Stars", count: 6, category: "imagery" },
];

export default function Analytics() {
  return (
    <div className="h-full overflow-auto" data-testid="page-analytics">
      <header className="p-4 md:p-6 border-b">
        <h1 className="text-2xl font-semibold">Analytics</h1>
        <p className="text-sm text-muted-foreground">
          Insights from your creative writing
        </p>
      </header>

      <main className="p-4 md:p-6 space-y-6">
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            label="Total Entries"
            value={mockStats.totalEntries}
            trend={12}
            icon={FileText}
          />
          <StatCard
            label="Total Words"
            value={mockStats.totalWords.toLocaleString()}
            trend={8}
            icon={PenLine}
          />
          <StatCard
            label="Avg Words/Entry"
            value={mockStats.avgWordsPerEntry}
            trend={-3}
            icon={TrendingUp}
          />
          <StatCard
            label="Writing Streak"
            value={`${mockStats.streakDays} days`}
            trend={0}
            icon={Calendar}
          />
        </div>

        <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Mood Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={mockMoodData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis 
                      dataKey="date" 
                      className="text-xs fill-muted-foreground"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      domain={[0, 100]} 
                      className="text-xs fill-muted-foreground"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px',
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="score"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary) / 0.2)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Writing Frequency</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={mockWeeklyData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis 
                      dataKey="day" 
                      className="text-xs fill-muted-foreground"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      className="text-xs fill-muted-foreground"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px',
                      }}
                    />
                    <Bar
                      dataKey="entries"
                      fill="hsl(var(--chart-2))"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 grid-cols-1 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Entry Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={mockTypeData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={70}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {mockTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px',
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap justify-center gap-3 mt-2">
                {mockTypeData.map((type) => (
                  <div key={type.name} className="flex items-center gap-1.5 text-sm">
                    <div
                      className="h-3 w-3 rounded-sm"
                      style={{ backgroundColor: type.color }}
                    />
                    <span className="text-muted-foreground">{type.name}</span>
                    <span className="font-mono text-xs">{type.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg">Top Motifs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {mockTopMotifs.map((motif) => (
                  <MotifTag
                    key={motif.id}
                    motif={motif}
                    onClick={() => console.log("Filter by motif:", motif.name)}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
