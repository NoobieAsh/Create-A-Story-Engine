import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { EntryEditor } from "@/components/EntryEditor";
import { AnalysisPanel } from "@/components/AnalysisPanel";
import NotFound from "@/pages/not-found";
import Archive from "@/pages/Archive";
import Analytics from "@/pages/Analytics";
import Prompts from "@/pages/Prompts";
import Characters from "@/pages/Characters";
import Locations from "@/pages/Locations";
import Settings from "@/pages/Settings";
import type { EntryType } from "@/components/EntryCard";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Archive} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/prompts" component={Prompts} />
      <Route path="/characters" component={Characters} />
      <Route path="/locations" component={Locations} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isNewEntryOpen, setIsNewEntryOpen] = useState(false);

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  const handleNewEntry = () => {
    setIsNewEntryOpen(true);
  };

  const handleSaveEntry = (data: { title: string; content: string; type: EntryType }) => {
    console.log("New entry created:", data);
    setIsNewEntryOpen(false);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider style={style as React.CSSProperties}>
          <div className="flex h-screen w-full">
            <AppSidebar onNewEntry={handleNewEntry} />
            <div className="flex flex-col flex-1 min-w-0">
              <header className="flex items-center justify-between gap-2 p-2 border-b shrink-0">
                <SidebarTrigger data-testid="button-sidebar-toggle" />
                <ThemeToggle />
              </header>
              <main className="flex-1 overflow-hidden">
                <Router />
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />

        <Dialog open={isNewEntryOpen} onOpenChange={setIsNewEntryOpen}>
          <DialogContent className="max-w-5xl h-[85vh] p-0 gap-0">
            <div className="flex h-full">
              <div className="flex-1 min-w-0">
                <EntryEditor
                  onSave={handleSaveEntry}
                  onCancel={() => setIsNewEntryOpen(false)}
                  onAnalyze={() => console.log("Analyzing new entry...")}
                />
              </div>
              <div className="w-80 border-l hidden lg:block">
                <AnalysisPanel />
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
