import { Progress } from "@/components/ui/progress";
import { Smile, Frown, Meh, Heart, Zap, Cloud, Sparkles } from "lucide-react";

export interface Sentiment {
  label: string;
  score: number;
  intensity: "low" | "medium" | "high";
}

const moodIcons: Record<string, typeof Smile> = {
  joy: Smile,
  sadness: Frown,
  neutral: Meh,
  love: Heart,
  excitement: Zap,
  melancholy: Cloud,
  wonder: Sparkles,
};

const intensityColors: Record<string, string> = {
  low: "text-chart-3",
  medium: "text-chart-4",
  high: "text-chart-5",
};

interface SentimentDisplayProps {
  sentiment: Sentiment;
  showBar?: boolean;
}

export function SentimentDisplay({ sentiment, showBar = true }: SentimentDisplayProps) {
  const Icon = moodIcons[sentiment.label.toLowerCase()] || Meh;
  const colorClass = intensityColors[sentiment.intensity];

  return (
    <div className="space-y-2" data-testid="sentiment-display">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Icon className={`h-5 w-5 ${colorClass}`} />
          <span className="font-medium capitalize">{sentiment.label}</span>
        </div>
        <span className="text-sm text-muted-foreground font-mono">
          {Math.round(sentiment.score)}%
        </span>
      </div>
      {showBar && (
        <Progress value={sentiment.score} className="h-2" />
      )}
    </div>
  );
}
