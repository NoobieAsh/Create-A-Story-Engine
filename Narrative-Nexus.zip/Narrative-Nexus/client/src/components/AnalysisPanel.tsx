import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SentimentDisplay, type Sentiment } from "./SentimentDisplay";
import { MotifTag, type Motif } from "./MotifTag";
import { CharacterCard, type Character } from "./CharacterCard";
import { LocationCard, type Location } from "./LocationCard";
import { Users, MapPin, Sparkles, Tags } from "lucide-react";

interface AnalysisPanelProps {
  sentiment?: Sentiment;
  motifs?: Motif[];
  characters?: Character[];
  locations?: Location[];
  onMotifClick?: (motif: Motif) => void;
  onCharacterClick?: (character: Character) => void;
  onLocationClick?: (location: Location) => void;
}

export function AnalysisPanel({
  sentiment,
  motifs = [],
  characters = [],
  locations = [],
  onMotifClick,
  onCharacterClick,
  onLocationClick,
}: AnalysisPanelProps) {
  return (
    <Card className="h-full flex flex-col" data-testid="analysis-panel">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-hidden">
        <Tabs defaultValue="sentiment" className="h-full flex flex-col">
          <TabsList className="w-full justify-start gap-1 mb-4">
            <TabsTrigger value="sentiment" className="text-xs" data-testid="tab-sentiment">
              Mood
            </TabsTrigger>
            <TabsTrigger value="motifs" className="text-xs" data-testid="tab-motifs">
              <Tags className="h-3 w-3 mr-1" />
              Motifs
            </TabsTrigger>
            <TabsTrigger value="characters" className="text-xs" data-testid="tab-characters">
              <Users className="h-3 w-3 mr-1" />
              Characters
            </TabsTrigger>
            <TabsTrigger value="locations" className="text-xs" data-testid="tab-locations">
              <MapPin className="h-3 w-3 mr-1" />
              Places
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="flex-1">
            <TabsContent value="sentiment" className="mt-0 space-y-4">
              {sentiment ? (
                <div className="space-y-4">
                  <SentimentDisplay sentiment={sentiment} />
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">
                      This entry expresses <span className="font-medium text-foreground">{sentiment.label}</span> with{" "}
                      <span className="font-medium text-foreground">{sentiment.intensity}</span> intensity.
                    </p>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  Write some content and click Analyze to see sentiment analysis.
                </p>
              )}
            </TabsContent>

            <TabsContent value="motifs" className="mt-0">
              {motifs.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {motifs.map((motif) => (
                    <MotifTag
                      key={motif.id}
                      motif={motif}
                      onClick={() => onMotifClick?.(motif)}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No motifs detected yet. Add more content to discover patterns.
                </p>
              )}
            </TabsContent>

            <TabsContent value="characters" className="mt-0 space-y-2">
              {characters.length > 0 ? (
                characters.map((character) => (
                  <CharacterCard
                    key={character.id}
                    character={character}
                    onClick={() => onCharacterClick?.(character)}
                  />
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No characters detected. Mention people in your writing to track them.
                </p>
              )}
            </TabsContent>

            <TabsContent value="locations" className="mt-0 space-y-2">
              {locations.length > 0 ? (
                locations.map((location) => (
                  <LocationCard
                    key={location.id}
                    location={location}
                    onClick={() => onLocationClick?.(location)}
                  />
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No locations detected. Describe places to track them across entries.
                </p>
              )}
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </CardContent>
    </Card>
  );
}
