import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export interface Character {
  id: string;
  name: string;
  role?: string;
  occurrences: number;
  stories: string[];
  color?: string;
}

const avatarColors = [
  "bg-chart-1 text-white",
  "bg-chart-2 text-white",
  "bg-chart-3 text-white",
  "bg-chart-4 text-white",
  "bg-chart-5 text-white",
];

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

function getColorForName(name: string): string {
  const index = name.charCodeAt(0) % avatarColors.length;
  return avatarColors[index];
}

interface CharacterCardProps {
  character: Character;
  onClick?: () => void;
}

export function CharacterCard({ character, onClick }: CharacterCardProps) {
  const colorClass = character.color || getColorForName(character.name);

  return (
    <Card 
      className="hover-elevate cursor-pointer"
      onClick={onClick}
      data-testid={`card-character-${character.id}`}
    >
      <CardContent className="flex items-center gap-3 p-4">
        <Avatar className="h-10 w-10">
          <AvatarFallback className={colorClass}>
            {getInitials(character.name)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <h4 className="font-medium truncate" data-testid={`text-character-name-${character.id}`}>
            {character.name}
          </h4>
          {character.role && (
            <p className="text-sm text-muted-foreground truncate">{character.role}</p>
          )}
        </div>
        <Badge variant="secondary" className="shrink-0 font-mono text-xs">
          {character.occurrences}
        </Badge>
      </CardContent>
    </Card>
  );
}
