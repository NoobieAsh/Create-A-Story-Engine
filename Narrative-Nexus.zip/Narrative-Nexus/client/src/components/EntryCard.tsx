import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { BookOpen, Feather, Moon, PenLine, Calendar } from "lucide-react";

export type EntryType = "story" | "journal" | "dream" | "poem";

export interface Entry {
  id: string;
  title: string;
  content: string;
  type: EntryType;
  date: string;
  wordCount: number;
  mood?: string;
  moodScore?: number;
}

const typeIcons: Record<EntryType, typeof BookOpen> = {
  story: BookOpen,
  journal: PenLine,
  dream: Moon,
  poem: Feather,
};

const typeColors: Record<EntryType, string> = {
  story: "bg-chart-1/10 text-chart-1",
  journal: "bg-chart-2/10 text-chart-2",
  dream: "bg-chart-3/10 text-chart-3",
  poem: "bg-chart-4/10 text-chart-4",
};

interface EntryCardProps {
  entry: Entry;
  onClick?: () => void;
}

export function EntryCard({ entry, onClick }: EntryCardProps) {
  const Icon = typeIcons[entry.type];
  const excerpt = entry.content.length > 120 
    ? entry.content.slice(0, 120) + "..." 
    : entry.content;

  return (
    <Card 
      className="hover-elevate cursor-pointer transition-all"
      onClick={onClick}
      data-testid={`card-entry-${entry.id}`}
    >
      <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
        <div className="flex items-center gap-2 flex-wrap">
          <Badge 
            variant="secondary" 
            className={`${typeColors[entry.type]} capitalize`}
          >
            <Icon className="h-3 w-3 mr-1" />
            {entry.type}
          </Badge>
          {entry.mood && (
            <Badge variant="outline" className="text-xs">
              {entry.mood}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <h3 className="font-semibold text-lg leading-tight line-clamp-1" data-testid={`text-title-${entry.id}`}>
          {entry.title}
        </h3>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {excerpt}
        </p>
        <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2">
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            {entry.date}
          </span>
          <span className="font-mono">{entry.wordCount} words</span>
        </div>
      </CardContent>
    </Card>
  );
}
