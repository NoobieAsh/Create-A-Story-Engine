import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Search, Filter, X, BookOpen, PenLine, Moon, Feather } from "lucide-react";
import type { EntryType } from "./EntryCard";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  filters?: EntryType[];
  onFiltersChange?: (filters: EntryType[]) => void;
  placeholder?: string;
}

const typeFilters: { value: EntryType; label: string; icon: typeof BookOpen }[] = [
  { value: "story", label: "Stories", icon: BookOpen },
  { value: "journal", label: "Journals", icon: PenLine },
  { value: "dream", label: "Dreams", icon: Moon },
  { value: "poem", label: "Poems", icon: Feather },
];

export function SearchBar({
  value,
  onChange,
  filters = [],
  onFiltersChange,
  placeholder = "Search entries...",
}: SearchBarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleFilter = (type: EntryType) => {
    if (filters.includes(type)) {
      onFiltersChange?.(filters.filter((f) => f !== type));
    } else {
      onFiltersChange?.([...filters, type]);
    }
  };

  const clearFilters = () => {
    onFiltersChange?.([]);
  };

  return (
    <div className="flex items-center gap-2 w-full max-w-md" data-testid="search-bar">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="pl-10 pr-4"
          data-testid="input-search"
        />
      </div>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className={filters.length > 0 ? "text-primary border-primary" : ""}
            data-testid="button-filters"
          >
            <Filter className="h-4 w-4" />
            {filters.length > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-primary-foreground text-[10px] flex items-center justify-center">
                {filters.length}
              </span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64" align="end">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Filter by type</span>
              {filters.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="h-auto py-1 px-2 text-xs"
                  data-testid="button-clear-filters"
                >
                  <X className="h-3 w-3 mr-1" />
                  Clear
                </Button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {typeFilters.map((type) => (
                <Badge
                  key={type.value}
                  variant={filters.includes(type.value) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleFilter(type.value)}
                  data-testid={`filter-${type.value}`}
                >
                  <type.icon className="h-3 w-3 mr-1" />
                  {type.label}
                </Badge>
              ))}
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
