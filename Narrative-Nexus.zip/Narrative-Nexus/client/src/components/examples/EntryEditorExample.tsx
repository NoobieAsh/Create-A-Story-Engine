import { EntryEditor } from "../EntryEditor";

export default function EntryEditorExample() {
  return (
    <div className="h-[500px]">
      <EntryEditor
        onSave={(data) => console.log("Saved:", data)}
        onAnalyze={() => console.log("Analyze clicked")}
      />
    </div>
  );
}
