import { StatCard } from "../StatCard";
import { FileText } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="max-w-xs">
      <StatCard
        label="Total Entries"
        value="48"
        trend={12}
        icon={FileText}
      />
    </div>
  );
}
