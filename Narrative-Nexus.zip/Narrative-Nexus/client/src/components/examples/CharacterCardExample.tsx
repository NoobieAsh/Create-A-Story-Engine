import { CharacterCard, type Character } from "../CharacterCard";

const mockCharacter: Character = {
  id: "1",
  name: "Elena Vance",
  role: "Protagonist",
  occurrences: 24,
  stories: ["The Garden", "Silent Waters"],
};

export default function CharacterCardExample() {
  return (
    <div className="max-w-sm">
      <CharacterCard character={mockCharacter} onClick={() => console.log("Character clicked")} />
    </div>
  );
}
