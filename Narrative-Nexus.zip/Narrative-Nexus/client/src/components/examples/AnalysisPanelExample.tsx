import { AnalysisPanel } from "../AnalysisPanel";
import type { Sentiment } from "../SentimentDisplay";
import type { Motif } from "../MotifTag";
import type { Character } from "../CharacterCard";
import type { Location } from "../LocationCard";

const mockSentiment: Sentiment = {
  label: "Wonder",
  score: 78,
  intensity: "high",
};

const mockMotifs: Motif[] = [
  { id: "1", name: "Water", count: 12, category: "symbol" },
  { id: "2", name: "Journey", count: 8, category: "theme" },
  { id: "3", name: "The Sage", count: 4, category: "archetype" },
];

const mockCharacters: Character[] = [
  { id: "1", name: "Marcus Webb", role: "Guide", occurrences: 8, stories: [] },
  { id: "2", name: "Lily Chen", role: "Companion", occurrences: 5, stories: [] },
];

const mockLocations: Location[] = [
  { id: "1", name: "The Crystal Lake", occurrences: 6, stories: [] },
  { id: "2", name: "Ancient Library", occurrences: 3, stories: [] },
];

export default function AnalysisPanelExample() {
  return (
    <div className="h-[400px] w-[320px]">
      <AnalysisPanel
        sentiment={mockSentiment}
        motifs={mockMotifs}
        characters={mockCharacters}
        locations={mockLocations}
      />
    </div>
  );
}
