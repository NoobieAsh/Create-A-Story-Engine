import { useState } from "react";
import { SearchBar } from "../SearchBar";
import type { EntryType } from "../EntryCard";

export default function SearchBarExample() {
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<EntryType[]>([]);

  return (
    <SearchBar
      value={search}
      onChange={setSearch}
      filters={filters}
      onFiltersChange={setFilters}
    />
  );
}
