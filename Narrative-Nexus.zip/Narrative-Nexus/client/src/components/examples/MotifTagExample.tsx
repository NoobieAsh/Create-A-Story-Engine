import { MotifTag, type Motif } from "../MotifTag";

const mockMotifs: Motif[] = [
  { id: "1", name: "Water", count: 15, category: "symbol" },
  { id: "2", name: "Transformation", count: 8, category: "theme" },
  { id: "3", name: "The Wanderer", count: 5, category: "archetype" },
  { id: "4", name: "Golden Light", count: 3, category: "imagery" },
];

export default function MotifTagExample() {
  return (
    <div className="flex flex-wrap gap-2 p-4">
      {mockMotifs.map((motif) => (
        <MotifTag key={motif.id} motif={motif} onClick={() => console.log("Motif clicked:", motif.name)} />
      ))}
    </div>
  );
}
