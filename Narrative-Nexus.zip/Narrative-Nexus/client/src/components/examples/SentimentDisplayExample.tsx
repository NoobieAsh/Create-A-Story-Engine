import { SentimentDisplay, type Sentiment } from "../SentimentDisplay";

const mockSentiment: Sentiment = {
  label: "Melancholy",
  score: 68,
  intensity: "medium",
};

export default function SentimentDisplayExample() {
  return (
    <div className="max-w-sm p-4">
      <SentimentDisplay sentiment={mockSentiment} />
    </div>
  );
}
