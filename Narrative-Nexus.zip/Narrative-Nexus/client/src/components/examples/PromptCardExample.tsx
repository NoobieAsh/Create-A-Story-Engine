import { useState } from "react";
import { PromptCard, type Prompt } from "../PromptCard";

const mockPrompt: Prompt = {
  id: "1",
  text: "Write about a character who discovers that their recurring dream is actually a memory from someone else's life.",
  genre: "mystery",
  complexity: "moderate",
  themes: ["identity", "memory", "connection"],
};

export default function PromptCardExample() {
  const [isSaved, setIsSaved] = useState(false);

  return (
    <div className="max-w-md">
      <PromptCard
        prompt={mockPrompt}
        isSaved={isSaved}
        onRefresh={() => console.log("Refresh prompt")}
        onSave={() => setIsSaved(!isSaved)}
        onUse={() => console.log("Use prompt")}
      />
    </div>
  );
}
