import { EntryCard, type Entry } from "../EntryCard";

const mockEntry: Entry = {
  id: "1",
  title: "The Garden of Forgotten Dreams",
  content: "I walked through a garden where flowers bloomed in impossible colors. Each petal held a memory I thought I had lost forever. The path wound deeper, and with each step, the air grew thick with nostalgia...",
  type: "dream",
  date: "Dec 4, 2024",
  wordCount: 342,
  mood: "Nostalgic",
  moodScore: 72,
};

export default function EntryCardExample() {
  return (
    <div className="max-w-sm">
      <EntryCard entry={mockEntry} onClick={() => console.log("Entry clicked")} />
    </div>
  );
}
