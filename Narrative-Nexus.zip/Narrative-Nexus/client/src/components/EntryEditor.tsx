import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Save, X, Sparkles, BookOpen, PenLine, Moon, Feather } from "lucide-react";
import type { EntryType } from "./EntryCard";

interface EntryEditorProps {
  initialTitle?: string;
  initialContent?: string;
  initialType?: EntryType;
  onSave?: (data: { title: string; content: string; type: EntryType }) => void;
  onCancel?: () => void;
  onAnalyze?: () => void;
  isAnalyzing?: boolean;
}

const typeOptions: { value: EntryType; label: string; icon: typeof BookOpen }[] = [
  { value: "story", label: "Story", icon: BookOpen },
  { value: "journal", label: "Journal", icon: PenLine },
  { value: "dream", label: "Dream", icon: Moon },
  { value: "poem", label: "Poem", icon: Feather },
];

export function EntryEditor({
  initialTitle = "",
  initialContent = "",
  initialType = "journal",
  onSave,
  onCancel,
  onAnalyze,
  isAnalyzing,
}: EntryEditorProps) {
  const [title, setTitle] = useState(initialTitle);
  const [content, setContent] = useState(initialContent);
  const [type, setType] = useState<EntryType>(initialType);

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const charCount = content.length;

  const handleSave = () => {
    if (title.trim() && content.trim()) {
      onSave?.({ title, content, type });
    }
  };

  return (
    <Card className="flex flex-col h-full" data-testid="entry-editor">
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-4 flex-wrap">
        <div className="flex items-center gap-2">
          <Select value={type} onValueChange={(v) => setType(v as EntryType)}>
            <SelectTrigger className="w-[140px]" data-testid="select-entry-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {typeOptions.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  <div className="flex items-center gap-2">
                    <opt.icon className="h-4 w-4" />
                    {opt.label}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onAnalyze}
            disabled={!content.trim() || isAnalyzing}
            data-testid="button-analyze"
          >
            <Sparkles className={`h-4 w-4 mr-1 ${isAnalyzing ? "animate-spin" : ""}`} />
            {isAnalyzing ? "Analyzing..." : "Analyze"}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-4">
        <Input
          placeholder="Give your entry a title..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-xl font-semibold border-0 px-0 focus-visible:ring-0"
          data-testid="input-entry-title"
        />
        <Textarea
          placeholder="Start writing your thoughts, dreams, or stories..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="flex-1 min-h-[300px] resize-none text-base leading-relaxed focus-visible:ring-0"
          data-testid="textarea-entry-content"
        />
      </CardContent>
      <CardFooter className="flex items-center justify-between gap-4 border-t pt-4 flex-wrap">
        <div className="flex items-center gap-4 text-sm text-muted-foreground font-mono">
          <span>{wordCount} words</span>
          <span>{charCount} chars</span>
          <Badge variant="outline" className="text-xs">Auto-saved</Badge>
        </div>
        <div className="flex items-center gap-2">
          {onCancel && (
            <Button variant="ghost" onClick={onCancel} data-testid="button-cancel-edit">
              <X className="h-4 w-4 mr-1" />
              Cancel
            </Button>
          )}
          <Button 
            onClick={handleSave} 
            disabled={!title.trim() || !content.trim()}
            data-testid="button-save-entry"
          >
            <Save className="h-4 w-4 mr-1" />
            Save
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
