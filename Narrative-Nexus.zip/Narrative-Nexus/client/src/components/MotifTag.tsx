import { Badge } from "@/components/ui/badge";

export interface Motif {
  id: string;
  name: string;
  count: number;
  category: "symbol" | "theme" | "archetype" | "imagery";
}

const categoryColors: Record<string, string> = {
  symbol: "bg-chart-1/10 text-chart-1 border-chart-1/20",
  theme: "bg-chart-2/10 text-chart-2 border-chart-2/20",
  archetype: "bg-chart-3/10 text-chart-3 border-chart-3/20",
  imagery: "bg-chart-4/10 text-chart-4 border-chart-4/20",
};

interface MotifTagProps {
  motif: Motif;
  onClick?: () => void;
}

export function MotifTag({ motif, onClick }: MotifTagProps) {
  const sizeClass = motif.count > 10 
    ? "text-base px-3 py-1" 
    : motif.count > 5 
    ? "text-sm px-2.5 py-0.5" 
    : "text-xs px-2 py-0.5";

  return (
    <Badge
      variant="outline"
      className={`${categoryColors[motif.category]} ${sizeClass} cursor-pointer`}
      onClick={onClick}
      data-testid={`motif-tag-${motif.id}`}
    >
      {motif.name}
      <span className="ml-1.5 opacity-60 font-mono text-[0.7em]">{motif.count}</span>
    </Badge>
  );
}
