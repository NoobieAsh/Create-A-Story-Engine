import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin } from "lucide-react";

export interface Location {
  id: string;
  name: string;
  description?: string;
  occurrences: number;
  stories: string[];
}

interface LocationCardProps {
  location: Location;
  onClick?: () => void;
}

export function LocationCard({ location, onClick }: LocationCardProps) {
  return (
    <Card 
      className="hover-elevate cursor-pointer"
      onClick={onClick}
      data-testid={`card-location-${location.id}`}
    >
      <CardContent className="flex items-center gap-3 p-4">
        <div className="flex items-center justify-center h-10 w-10 rounded-md bg-muted">
          <MapPin className="h-5 w-5 text-muted-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-medium truncate" data-testid={`text-location-name-${location.id}`}>
            {location.name}
          </h4>
          {location.description && (
            <p className="text-sm text-muted-foreground truncate">{location.description}</p>
          )}
        </div>
        <Badge variant="secondary" className="shrink-0 font-mono text-xs">
          {location.occurrences}
        </Badge>
      </CardContent>
    </Card>
  );
}
