import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Bookmark, PenLine } from "lucide-react";

export interface Prompt {
  id: string;
  text: string;
  genre?: string;
  complexity: "simple" | "moderate" | "complex";
  themes?: string[];
}

const complexityColors: Record<string, string> = {
  simple: "bg-chart-3/10 text-chart-3",
  moderate: "bg-chart-4/10 text-chart-4",
  complex: "bg-chart-5/10 text-chart-5",
};

interface PromptCardProps {
  prompt: Prompt;
  onRefresh?: () => void;
  onSave?: () => void;
  onUse?: () => void;
  isSaved?: boolean;
}

export function PromptCard({ prompt, onRefresh, onSave, onUse, isSaved }: PromptCardProps) {
  return (
    <Card className="flex flex-col" data-testid={`card-prompt-${prompt.id}`}>
      <CardContent className="flex-1 pt-6 space-y-4">
        <p className="text-lg leading-relaxed font-serif" data-testid={`text-prompt-${prompt.id}`}>
          "{prompt.text}"
        </p>
        <div className="flex flex-wrap gap-2">
          {prompt.genre && (
            <Badge variant="outline" className="capitalize">
              {prompt.genre}
            </Badge>
          )}
          <Badge className={complexityColors[prompt.complexity]}>
            {prompt.complexity}
          </Badge>
          {prompt.themes?.map((theme) => (
            <Badge key={theme} variant="secondary" className="text-xs">
              {theme}
            </Badge>
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex gap-2 pt-0">
        <Button
          size="sm"
          variant="ghost"
          onClick={onRefresh}
          data-testid={`button-refresh-prompt-${prompt.id}`}
        >
          <RefreshCw className="h-4 w-4 mr-1" />
          New
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={onSave}
          className={isSaved ? "text-chart-4" : ""}
          data-testid={`button-save-prompt-${prompt.id}`}
        >
          <Bookmark className={`h-4 w-4 mr-1 ${isSaved ? "fill-current" : ""}`} />
          {isSaved ? "Saved" : "Save"}
        </Button>
        <Button
          size="sm"
          variant="default"
          onClick={onUse}
          className="ml-auto"
          data-testid={`button-use-prompt-${prompt.id}`}
        >
          <PenLine className="h-4 w-4 mr-1" />
          Write
        </Button>
      </CardFooter>
    </Card>
  );
}
